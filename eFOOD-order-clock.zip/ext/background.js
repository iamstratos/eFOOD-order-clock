var rawTime = '';

chrome.extension.onMessage.addListener(function(response, sender, sendResponse) {
    rawTime = response;
    chrome.browserAction.setBadgeText({text: rawTime.replace(/\D/g,'') });
});